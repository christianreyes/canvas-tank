- - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
Title:			Project 2: Doodle!
Author : 		Christian Reyes 
Description:    Javascript for Doodle
Course:         05-433D SSUI Web Lab
Created : 		29 Sep 2011
Modified : 		 9 Oct 2011
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

Instructions!
			
Left/right arrow to move the truck. Up/down arrow to move the launcher. Space bar to shoot an arrow.

The p2-containers-test and the p2-primitives-test need to be refreshed in order to properly load the images.

There is also a glitch of switching tabs or not having the game in focus. Lots of balls load up and want to move across the screen.